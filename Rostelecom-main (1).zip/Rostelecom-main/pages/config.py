# Основной URL тестируемого сайта
MAIN_URL = 'https://b2c.passport.rt.ru'